import pandas as pd

df = pd.read_csv('login_data.csv')
print("First 5 rows of the CSV:")
print(df.head())  # Show first 5 rows of the dataset
